<html>
	<head>
		<title>Jeparadise Furniture | Order</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
		
<style>
* {
  box-sizing: border-box;
}
.menu {
  float:left;
  width:20%;
  font-family:verdana;
  text-align:center;
}
.menuitem {
  background-color:#ffd41d;
  padding:8px;
  margin-top:7px;
  
}
a{
	color:black;text-decoration:none;

}
a:hover{
	color:#848484;text-decoration:none;



}
#navbar {
  background-color: #333;
  position: fixed;
  top: -100px;
  width: 100%;
  display:block;
  transition: top 0.3s;
}

#navbar a {
  	display: block;
	color: white;
	text-align: center;
	padding: 14px 16px;
	text-decoration: none;
}

#navbar a:hover:not(.active){
	background-color: #111;
}
.active{
	background-color: #ffd41d;
	color: black;
}
ul {

	list-style-type: none;
	margin: 0;
	padding: 0;
	overflow: hidden;
	background-color: #333;
}
li{
	float: right;

}
li a{
	display: block;
	color: white;
	text-align: center;
	padding: 14px 16px;
	text-decoration: none;
}
li a:hover:not(.active){
	background-color: #111;
}
.active{
	background-color: #ffd41d;
	color: black;
}


.main {
  background-color: #fafafa;
  margin-top: 10px;
  float:left;
  width:80%;
  padding:0 20px;
  font-family:verdana;
}

.img-responsive{
	display:block;
	max-width:100%;
	height:auto
}

input[type=text], select {
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    size: 50;
    box-sizing: border-box;
}

textarea{
    width: 50%;
    height: 150px;
    padding: 12px 20px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    background-color: #f8f8f8;
    resize: none;
}

input[type=submit] {

    width: 10%;
    background-color: white;
    color: black;
    padding: 14px 20px;
    margin: 8px 0;
    border: 2px solid #008CBA;
    border-radius: 4px;
    cursor: pointer;
}
input[type=reset] {

    width: 10%;
    background-color: white;
    color: black;
    padding: 14px 20px;
    margin: 8px 20;
    border: 2px solid #ff8080;
    border-radius: 4px;
    cursor: pointer;

}

input[type=submit]:hover {
    background-color: #008CBA;
    color: white;
}
input[type=reset]:hover {
    background-color: #ff8080;
    color: white;
}

@media only screen and (max-width:620px) {
  /* For mobile phones: */
  .menu, .main, .right {
    width:100%;
  }
}
</style>
	</head>

	<body background-color="#cfcfcf">
		<font color="#4c4c4c">


		<div style="background-color:#ffd41d;padding:1px;text-align:left;">
			<h3 style="font-family:verdana; margin-left:20px;">JEPARADISE FURNITURE</h3>
		</div>
		
		<ul>
			<li><a href="tentang.html">TENTANG KAMI</a></li>
			<li><a class="active" href="order.html">PESAN SEKARANG</a></li>
			<li><a href="produk.html">PRODUK</a></li>
			<li><a href="index.html">HOME</a></li>

		</ul>
		<div id="navbar">
			<li><a href="tentang.html">TENTANG KAMI</a></li>
			<li><a class="active" href="order.html">PESAN SEKARANG</a></li>
			<li><a href="produk.html">PRODUK</a></li>
			<li><a href="index.html">HOME</a></li>

		</div>


		<div style="overflow:auto">
		<div class="menu">
			<div class="menuitem"><a href="sofa.html">Sofa</a></div>
			<div class="menuitem"><a href="penyimpanan.html">Penyimpanan</a></div>
			<div class="menuitem"><a href="mejakursi.html">Meja & Kursi</a></div>
			<div class="menuitem"><a href="bed.html">Tempat Tidur</a></div>
			<div class="menuitem"><a href="dekorasi.html">Dekorasi Rumah</a></div>
		<br>
	
					<font face="verdana">
				
			<div class="menuitem">
			<h4>Kontak Kami</h4>
			<p>Hari & Jam Kerja:<br>
	Senin - Minggu / 10.00 - 18.30<br>
	Buka setiap hari.</p>
			<img src="images/whatsapp.png" alt="Phone/whatsapp">

			<p>085601833012</p>

			<img src="images/phone-call.png" alt="Phone/whatsapp">

			<p>085601833012</p>
			<img src="images/blackberry.png" alt="bbm">

			<p>D117DCB5</p>
			<img src="images/gmail.png" alt="gmail">

			<p>jeparadisefurniture@gmail.com</p>
		</font>
	</div>
		</div>
	
			
	
		<div class="main">

			<font face="verdana">


					<h3 style="text-align: justify;">Selamat !!!</h3>
					<p dir="ltr"><span>Pesanan anda telah kami proses </span><span></span></p>

						Nama            : <?php echo $_POST["nama"]; ?><br>
						Alamat E-mail   : <?php echo $_POST["mail"]; ?><br>
						Nomor Handphone : <?php echo $_POST["hp"]; ?><br>
						Jenis Produk    : <?php echo $_POST["tipe"]; ?><br>
						Kode Produk     : <?php echo $_POST["kode"]; ?><br>
						Jumlah Produk   : <?php echo $_POST["jumlah"]; ?><br>
						Alamat Penerima : <?php echo $_POST["alamat"]; ?>

				  </form>

				
				
			</font>
				

			<br><br>


		</div>


	
		</div>
		<div style="background-color:#ffd41d;text-align:center;padding:10px;margin-top:7px;">
			<table width=100%>
				<tr>
					<td width="350px" heigth="66px">
						<img src="images/home.gif" alt="sofa" class="img-responsive">
					</td>
					<td width="350px" heigth="66px">
						<img src="images/footer.png" alt="sofa" class="img-responsive">
						</td>
			</table>


		</div>
	</font>
		<script type="text/javascript">
		window.onscroll = function() {scrollFunction()};

		function scrollFunction() {
		    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
		        document.getElementById("navbar").style.top = "0";
		    } else {
		        document.getElementById("navbar").style.top = "-100px";
		    }
		}
	</script>


	</body>



</html>